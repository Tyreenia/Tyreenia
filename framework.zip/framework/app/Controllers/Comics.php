<?php

namespace App\Controllers;

use App\Models\ComicsModel;

class Comics extends BaseController
{
    public function __construct()
    {
        $this->ComicsModel = new ComicsModel();
    }

    public function index()
    {
        $Comics = $this->ComicsModel->findAll();

        $data = [
            'title' => '3 makanan termahal di Indonesia',
            'Comics' => $Comics
        ];

        // $ComicsModel = new \app\Models\ComicsModel();


        return view('Comics/index', $data);
    }
}
