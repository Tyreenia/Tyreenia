<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<?= $this->endSection(); ?>